#!/usr/bin/env python3
import numpy as np
import pandas as pd

from flask import Flask
from flask import render_template

app = Flask(__name__)

@app.route("/")
def chart():
    df = pd.read_csv('data/data.csv')
    days = np.unique(df['day'])

    allValues = {}
    for day in days:
        df_ = df.query('day==' + str(day))
        labels = df_['hour']
        print(labels)
        values_dewp = df_['DEWP']
        values_temp = df_['TEMP']
        values1 = [values_dewp, values_temp, labels]
        allValues[day] = values1
    return render_template('charts.html', days = days, values=allValues)

@app.route('/view')
def view():
    data= pd.read_csv('data/data.csv')
    columns = ['year','month','day','gender','births']
    data = pd.read_csv('data/data.csv')
    data['decade'] = 10 * (data['year'] // 10)
    data.pivot_table('DEWP', index='decade', columns='TEMP', aggfunc='sum')
    dataview = list(data.values)

    return render_template('view.html',dataview=dataview)

    
if __name__ == "__main__":
    app.run('0.0.0.0')
 